app.controller("page_two",page_two);
function page_two($scope){
	$scope.var_two="I am from page two controller !";
}