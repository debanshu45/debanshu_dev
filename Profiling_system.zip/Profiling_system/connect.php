<?php 
	$host = "localhost";
	$user = "root";
	$pass = "root";

	try {
		$con = new PDO("mysql:host=$host;dbname=profiling system", $user, $pass);
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch (PDOException $e) {
		echo 'Connection Failed:' . $e->getMessage();
	}
?>