    /*shrink top header*/
 /*   $(document).ready(function() {
        var scrollTop = 0;
        $(window).scroll(function() {
            scrollTop = $(window).scrollTop();
            if (scrollTop >= 90) {
                $('#header').fadeOut("slow");
                $('#sticky-header').addClass('sticky');
            }
            else if(scrollTop <= 90) {
                 $('#header').fadeIn("slow");
                 $('#sticky-header').removeClass('sticky');
            }
        });
    });*/