import { Component, Input } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-training';

  @Input() currentCurrency:string;

  updateCurrency(code:string) {
    this.currentCurrency = code;
  }
}
