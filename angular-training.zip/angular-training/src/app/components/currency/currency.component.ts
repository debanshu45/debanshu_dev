import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {

  codes = ['INR','USD','EUR','GBP','CAD'];

  @Output() selected = new EventEmitter();

  trackByCode(index:number, code:string){
    code
  }

  constructor() { }

  ngOnInit(): void {
  }

  changeCurency(code:any) {
    this.selected.emit(code.value)
  }

}
