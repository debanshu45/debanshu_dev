import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { productType } from 'src/types';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  @Input() code: string;

  @Input() pData:productType | null = null;

  @Input() wishlist:boolean = false;

  // @Input() inStock:boolean;

  @Output() btnClick = new EventEmitter();

  

  //always best practices to write the condition interms of function
  get btntext() {
    if(!this.wishlist){
      return 'cart'
    }
    return 'wishlist' 
  }

  notifyparent() {
    this.btnClick.emit(this.pData?.productID)
  }

  constructor() { }

  ngOnInit(): void {
    
  }

}
