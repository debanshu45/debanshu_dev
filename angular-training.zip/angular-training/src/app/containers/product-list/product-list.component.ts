import { Component, Input, OnInit } from '@angular/core';
import { productType } from 'src/types';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  @Input() selectedCurrency: string = ''

  plist:productType[] = [
    {
    productID:1000,
    productImage:'/assets/product-1.jpeg',
    productnName:"product -1",
    productPrice:12999,
    productStock:true
  },
  {
    productID:1000,
    productImage:'/assets/product-1.jpe',
    productnName:"product -1",
    productPrice:12999,
    productStock:true
  }
]

  addToCart(eve:number) {
    console.log('Add to cart', eve);
  }

  addToWishlist(eve:number) {
    console.log('Add to Wishlist', eve);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
