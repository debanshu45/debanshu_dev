import { ImageFallbackDirective } from './image-fallback.directive';

describe('ImageFallbackDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageFallbackDirective();
    expect(directive).toBeTruthy();
  });
});
