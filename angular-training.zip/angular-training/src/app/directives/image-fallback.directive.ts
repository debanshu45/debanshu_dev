import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { environment } from 'src/environments/environment';

@Directive({
  selector: '[appImageFallback]'
})
export class ImageFallbackDirective {

  constructor(private eRef: ElementRef) { }

  @Input() appImageFallback: string | null = null

  defaultImage = environment.fallBackImage

  @HostListener('error')
  loadFallbackOnError() {
    const element: HTMLImageElement = <HTMLImageElement>this.eRef.nativeElement;
    element.src = this.appImageFallback || this.defaultImage ;
  }

}
