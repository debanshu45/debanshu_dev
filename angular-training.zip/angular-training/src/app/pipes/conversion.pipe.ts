import { Pipe, PipeTransform } from '@angular/core';
import { environment } from 'src/environments/environment';

@Pipe({
  name: 'conversion'
})
export class ConversionPipe implements PipeTransform {

  transform(value: number | undefined, code:string = environment.currency): unknown {
    if(!value) return null;
    if(isNaN(value)) return null;
    return this.convertPrice(value, code);
  }

  convertPrice(price:number, code:string) {
    switch(code){
      case 'USD':
        return (price/= 70);
        case 'EUR':
        return (price/= 50);
        case 'GBP':
        return (price/= 10);
        case 'CAD':
        return (price/= 20);
       default:
        return price
    }
  }
}
