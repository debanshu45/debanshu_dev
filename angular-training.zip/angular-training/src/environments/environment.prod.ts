export const environment = {
  production: true,
  currency:'USD'
};
