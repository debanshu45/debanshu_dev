
export type productType =  {
    productID:number;
    productnName:string;
    productPrice:number;
    productImage:string;
    productStock:boolean
}