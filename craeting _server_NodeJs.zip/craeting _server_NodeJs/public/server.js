var http=require('http');
var fs=require('fs');

function onRequest(req,res){
	res.writeHead(200,{"Content-Type":"text/plain"});
	res.write("welcome to nodejs");
	res.end();
}

http.createServer(onRequest).listen(3000);
console.log("server is now running..");