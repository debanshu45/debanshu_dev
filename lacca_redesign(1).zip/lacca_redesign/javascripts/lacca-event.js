$(document).ready(function() {
    var e = $("#slider"),
        t = $("#carousel"),
        o = !0;

    function i(e) {
        e.target;
        var t = e.item.count,
            o = e.item.index + 1;
        o > t && (o -= t), $(".current_slide").html(o), $(".total_slide").html(t)
    }
    e.owlCarousel({
        items: 1
    }).on("changed.owl.carousel"), t.on("initialized.owl.carousel", function() {
        t.find(".owl-item").eq(0).addClass("current")
    }).owlCarousel({
        items: 4,
        margin: 15,
        nav: !0,
        loop: !0,
        onInitialized: i,
        onTranslated: i
    }).on("changed.owl.carousel", function(t) {
        if (o) {
            var i = t.item.index;
            e.data("owl.carousel").to(i, 100, !0)
        }
    }), t.on("click", ".owl-item", function(t) {
        t.preventDefault();
        var o = $(this).index();
        e.data("owl.carousel").to(o, 300, !0)
    })
}), $(document).ready(function() {
    $("#slider-testimonial").flexslider({
        animation: "slide",
        animationLoop: !0
    })
}), equalHeight = function(e) {
    var t, o = 0,
        i = new Array;
    $(e).each(function() {
        for (t = $(this), $(t).height("auto"), i.push(t), o = o < t.height() ? t.height() : o, currentDiv = 0; currentDiv < i.length; currentDiv++) i[currentDiv].height(o)
    })
}, $(function() {
    $(window).width() > 480 ? setTimeout(function() {
        equalHeight(".common-profile")
    }, 1200) : $(".common-profile").css("height", "auto")
})
    
    , $(document).on("click", 'a[href^="#"]', function(e) {
    e.preventDefault(), $("html, body").animate({
        scrollTop: $($.attr(this, "href")).offset().top
    }, 500)
}), $(document).ready(function() {
    $(".programme-inner-block .view-all").prev().children(".programme-right").css("padding-bottom", "20px"), $("#tab_block").tabs()
});