 $(document).ready(function() {
   $(function() {
    $(".dropdown > a").click(function(e) {
      e.preventDefault();
      var a=$(this).attr("data-id");
      if (!$('#'+a).parent("li").hasClass('dropmenu')){
        $('.dropdown').removeClass("dropmenu");
        $("#"+a).parent("li").addClass("dropmenu");
      }else{
        $("#"+a).parent("li").toggleClass("dropmenu");
      }

    });
  });
 });

 /**/
 $(window).resize(function() {
  $(".dropdown").removeClass("dropmenu");
});

 /*responsive-menu*/
 $(".main-menu,.cont-menu-list").click(function () {
  if ($("#wrapper").hasClass('width-increase') != true) {
    $("#wrapper").addClass('width-increase');
    $(".cont-submenu").show();
    /* $("#wrapper").css({ 'position': 'fixed'});*/
  } else {
    $("#wrapper").removeClass('width-increase');
    $(".cont-submenu,.cont-news-sub").hide();
    /*$("#wrapper").css({ 'position': 'relative'});*/
  }
});

 $(function () {
  $(window).on("resize orientation load", function () {
    var windowwidth = $(window).width();
    if (windowwidth >= 490) {
      $("#wrapper").removeClass('width-increase');
      $(".cont-submenu").hide().css("display", "none");
      $("#wrapper").css({"overflow": "hidden", 'position': 'relative'});
    }
  });
});

 $(function () {
  $(".list-cont>li").click(function(){
   if($(this).find(".cont-news-sub").is(':visible') != true ){   
    $(".list-cont li").removeClass("shown-submenu");
    $(this).children("a").parent("li.sub_arrow").addClass("shown-submenu");
  }else{
   $(this).children("a").parent("li.sub_arrow").removeClass("shown-submenu");
 }
});
});

 /*article-gallery*/

/* $(document).ready(function(){
  slider = $("#slider");
  carousel = $("#carousel");

  carousel.on('changed.owl.carousel', function(event) {
    slider.trigger('next.owl.carousel');
  });

  slider.owlCarousel({
    items:1
  });

  carousel.owlCarousel({
    loop:true,
    margin:15,
    items:4
  });

});
 */
 $(document).ready(function() {

  var slider = $("#slider");
  var carousel = $("#carousel");
  var syncedSecondary = true;

  slider.owlCarousel({
    items: 1,
  }).on('changed.owl.carousel');

  carousel
  .on('initialized.owl.carousel', function() {
    carousel.find(".owl-item").eq(0).addClass("current");
  }).owlCarousel({
    items:4,
    margin: 15,
    nav:true,
    loop:true,
    onInitialized  : counter, //When the plugin has initialized.
  onTranslated : counter, //When the translation of the stage has finished.
  }).on('changed.owl.carousel', syncPosition2);



  function syncPosition2(el) {
    if (syncedSecondary) {
      var number = el.item.index;
      slider.data('owl.carousel').to(number, 100, true);
    }
  }


  function counter(event) {
   var element   = event.target;         // DOM element, in this example .owl-carousel
    var items     = event.item.count;     // Number of items
    var item      = event.item.index + 1;     // Position of the current item

  // it loop is true then reset counter from 1
  if(item > items) {
    item = item - items
  }
/*  $('#counter').html(item+" / "+items)
*/  $('.current_slide').html(item);
  $('.total_slide').html(items);
}


carousel.on("click", ".owl-item", function(e) {
  e.preventDefault();
  var number = $(this).index();
  slider.data('owl.carousel').to(number, 300, true);
});


});


/*
 $(document).ready(function () {
  $('#carousel').flexslider({
    animation: "slide",
    controlNav:false,
    autoPlay: true,
    animationLoop:true,
    slideshow:true,
    itemWidth:176,
    itemMargin:15,
    slideshowSpeed: 4000,
    asNavFor: '#slider',
    start: function (slider) {
      slider.find('.current-slide').text(slider.currentSlide+1);
      slider.find('.total-slides').text(slider.count);
    },
    after: function (slider) {
     slider.find('.current-slide').text(slider.currentSlide+1);
     slider.find('.total-slides').text(slider.count);
     if (!slider.playing) {
      slider.play();
    }
  }
});

  $('#slider').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: false,
    sync: "#carousel",
    controlsContainer: ".flex-container",
    start: function(slider) {
      $('.total-slides').text(slider.count);
    },
    after: function(slider) {
      $('.current-slide').text(slider.currentSlide);
    }
  });
});*/




 /*article-pgae gallery*/
  //init masonry grid
/*  $(window).on("load", function() {
    $('#gallery-image').masonry({
      itemSelector: '.gallery-column',
    });
  })
 */

 /*article-pgae gallery light box*/
 $(document).ready(function() {
  $('.gallery-column a').click(function() {
    $(".lightbox").addClass("lightcolor");
  });

  $("#article_gallery").click(function() {
    $(".lightbox").removeClass("lightcolor");
  });
});

 /*lost-password*/
 $('.summit').on('click',function (e) {
  $('.wdata-error').hide();
  e.preventDefault();
  var user_name = $('#subscriber_user_name').val();
  console.log(user_name);
  if ($("#subscriber_user_name").val() == ""){
    $("#subscriber_user_name").addClass('error')
    $('.empty-error').show();
  }
  else {
    $.ajax({
      type: "POST",
      url: "/forgot_password_mail",
      data: "subscriber[user_name]=" + user_name,
      datatype: "html",
      beforeSend: function (xhr) {
        xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'))
        $("#subscriber_user_name").removeClass('error')
        $("#export_loader").show();
        $('.empty-error').hide();
      },
      success: function (data) {
        $("#export_loader").hide();
        $('.wdata-error').html(data).show();
        if(data.indexOf("not") != -1){
          $("#subscriber_user_name").addClass('error')
        }
        $("#subscriber_user_name").val("");
      }
    });
  }
});

 /*event page -testimonial-block*/
 $(document).ready(function () {

  $('#slider-testimonial').flexslider({
    animation: "slide",      
    animationLoop: true
  });
});

 $(document).ready(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlsContainer: ".flex-container",
    start: function(slider) {
      $('.total-slides').text(slider.count);
    },
    after: function(slider) {
      $('.current-slide').text(slider.currentSlide);
    }
  });
});

 /*footer menu toggle script*/


 $(window).bind("load resize",function(e){
  // do stuff
  if ($(window).width() < 769) {
    $(".menu_title").click(function () {
      $(this).toggleClass("main");
      $(this).next(".list-group").toggle();
    });

  }
});


 $(document).ready(function(){
  $(".programme-inner-block .view-all").prev().children(".programme-right").css("padding-bottom", "20px");
});




