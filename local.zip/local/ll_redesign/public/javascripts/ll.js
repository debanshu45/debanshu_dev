 $(document).ready(function() {
     $(function() {
          $(".dropdown > a").click(function(e) {
          e.preventDefault();
        var a=$(this).attr("data-id");
        if (!$('#'+a).parent("li").hasClass('dropmenu')){
          $('.dropdown').removeClass("dropmenu");
          $("#"+a).parent("li").addClass("dropmenu");
        }else{
          $("#"+a).parent("li").toggleClass("dropmenu");
        }

      });
     });
      });

 /**/
 $(window).resize(function() {
        $(".dropdown").removeClass("dropmenu");
      });

     /*responsive-menu*/
    $(".main-menu,.cont-menu-list").click(function () {
        if ($("#wrapper").hasClass('width-increase') != true) {
            $("#wrapper").addClass('width-increase');
            $(".cont-submenu").show();
            /* $("#wrapper").css({ 'position': 'fixed'});*/
        } else {
            $("#wrapper").removeClass('width-increase');
            $(".cont-submenu,.cont-news-sub").hide();
            /*$("#wrapper").css({ 'position': 'relative'});*/
        }
    });

    $(function () {
        $(window).on("resize orientation load", function () {
            var windowwidth = $(window).width();
            if (windowwidth >= 490) {
                $("#wrapper").removeClass('width-increase');
                $(".cont-submenu").hide().css("display", "none");
                $("#wrapper").css({"overflow": "hidden", 'position': 'relative'});
            }
        });
    });

  $(function () {
$(".list-cont>li").click(function(){
   if($(this).find(".cont-news-sub").is(':visible') != true ){   
        $(".list-cont li").removeClass("shown-submenu");
     $(this).children("a").parent("li.sub_arrow").addClass("shown-submenu");
    }else{
     $(this).children("a").parent("li.sub_arrow").removeClass("shown-submenu");
    }
   });
});

/*equal height*/
    equalheightDiff = function(container){
        var currentTallest = 0,
            currentRowStart = 0,
            rowDivs = new Array(),
            $el,
            topPosition = 0;
        $(container).each(function() {

            $el = $(this);
            $($el).height('auto');
            topPostion = $el.position().top;

            /*if (currentRowStart != topPostion) {
                for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
                    rowDivs[currentDiv].height(currentTallest);
                }
                rowDivs.length = 0; // empty the array
                currentRowStart = topPostion;
                currentTallest = $el.height();
                rowDivs.push($el);
            } else {*/
                rowDivs.push($el);
                currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
            //}
            for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
                rowDivs[currentDiv].height(currentTallest);
            }
        });
    };
    equalheightDiff('.insight .insight-list');

    $(window).on("resize",function(){
        equalheightDiff('.insight .insight-list');
    });



/*lost-password*/
 $('.summit').on('click',function (e) {
        $('.wdata-error').hide();
          e.preventDefault();
          var user_name = $('#subscriber_user_name').val();
          console.log(user_name);
          if ($("#subscriber_user_name").val() == ""){
              $("#subscriber_user_name").addClass('error')
              $('.empty-error').show();
          }
          else {
              $.ajax({
                  type: "POST",
                  url: "/forgot_password_mail",
                  data: "subscriber[user_name]=" + user_name,
                  datatype: "html",
                  beforeSend: function (xhr) {
                      xhr.setRequestHeader('X-CSRF-Token', $('meta[name="csrf-token"]').attr('content'))
                      $("#subscriber_user_name").removeClass('error')
                      $("#export_loader").show();
                      $('.empty-error').hide();
                  },
                  success: function (data) {
                      $("#export_loader").hide();
                      $('.wdata-error').html(data).show();
                      if(data.indexOf("not") != -1){
                          $("#subscriber_user_name").addClass('error')
                      }
                      $("#subscriber_user_name").val("");
                  }
              });
          }
      });


/*article-gallery*/

$(document).ready(function () {
    $('#carousel').flexslider({
      animation: "slide",
      controlNav: false,
      animationLoop: false,
      slideshow: false,
      itemWidth: 190,
      itemMargin: 6,
      asNavFor: '#slider'
    });

    $('#slider').flexslider({
      animation: "slide",
      controlNav: false,
      animationLoop: false,
      slideshow: false,
      sync: "#carousel"
    });
  });

 /*article-pgae gallery*/
  //init masonry grid
  $(window).on("load", function() {
    $('#gallery-image').masonry({
      itemSelector: '.gallery-column',
    });
  })
  

/*article-pgae gallery light box*/
          $(document).ready(function() {
        $('.gallery-column a').click(function() {
          $(".lightbox").addClass("lightcolor");
        });
      
      $("#article_gallery").click(function() {
          $(".lightbox").removeClass("lightcolor");
        });
      });
  
/*footer menu list 767*/
        $(document).ready(function () {
            equalheight('.show-767 .footer-list .footer-menu-list');
        });
        equalheight = function(container){
            var currentTallest = 0,
                currentRowStart = 0,
                rowDivs = new Array(),
                $el,
                topPosition = 0;
            $(container).each(function() {

                $el = $(this);
                $($el).height('auto');

                rowDivs.push($el);
                currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);

                for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
                    rowDivs[currentDiv].height(currentTallest);
                }
            });
        };
/*article-pagination*/
        $(function () {
    if($('.article-pagination').length != 0 && $('.previous>a').length < 1){
      $('.previous').hide()
    }
    else if($('.article-pagination').length != 0 && $('.next>a').length < 1){
      $('.next').hide()
    }
    if($('.article-pagination').length != 0 && $('.disabled').length >0){
      $('.disabled').hide()
    }
    
  });
    